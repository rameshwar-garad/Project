package backend;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

public class Backend {
    private static final String URL = "jdbc:mysql://localhost:3306/transactions_db?useSSL=false";
    private static final String USER = "root";
    private static final String PASSWORD = "root";

    public static void main(String[] args) {
       
        String filePath = "D:/JSP/BackendProject/data/amazon_tx_data.csv";

        try (Connection conn = DriverManager.getConnection(URL, USER, PASSWORD)) {
            System.out.println("Connected to database!");

            
            BufferedReader br = new BufferedReader(new FileReader(filePath));
            String line;

           
            br.readLine();

           
            String insertSQL = "INSERT INTO Transaction (transaction_id, price, quantity) VALUES (?, ?, ?) "
                             + "ON DUPLICATE KEY UPDATE price = VALUES(price), quantity = VALUES(quantity)";
            PreparedStatement pstmt = conn.prepareStatement(insertSQL);

            while ((line = br.readLine()) != null) {
                String[] data = line.split(",");

               
                if (data.length >= 9) { 
                    try {
                        pstmt.setString(1, data[0]);  // Transaction ID (String)
                        pstmt.setDouble(2, Double.parseDouble(data[6])); // Final Price (Double)
                        pstmt.setInt(3, Integer.parseInt(data[4])); // Quantity (Integer)
                        pstmt.executeUpdate();
                    } catch (NumberFormatException e) {
                       
                    }
                }
            }

            System.out.println("Data imported successfully!");
            br.close();

            
            ResultSet rs = conn.createStatement().executeQuery("SELECT * FROM Transaction");
            while (rs.next()) {
                System.out.println("ID: " + rs.getInt("id") + ", Transaction ID: " + rs.getString("transaction_id") +
                        ", Price: " + rs.getDouble("price") + ", Quantity: " + rs.getInt("quantity"));
            }

        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}
