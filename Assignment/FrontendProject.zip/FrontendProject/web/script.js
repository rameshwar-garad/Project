document.addEventListener("DOMContentLoaded", function() {
    fetch("http://localhost:8080/transactions")  // Fetch data from backend
        .then(response => response.json())
        .then(data => {
            let tableBody = document.getElementById("transactionTable");
            tableBody.innerHTML = ""; // Clear table before inserting data
            
            data.forEach(transaction => {
                let row = `<tr>
                    <td>${transaction.transaction_id}</td>
                    <td>${transaction.price}</td>
                    <td>${transaction.quantity}</td>
                </tr>`;
                tableBody.innerHTML += row;
            });
        })
        .catch(error => console.error("Error fetching transactions:", error));
});


function filterData() {
    let searchValue = document.getElementById("searchBox").value.toLowerCase();
    let rows = document.querySelectorAll("#transactionTable tr");

    rows.forEach(row => {
        let transactionID = row.cells[0].textContent.toLowerCase();
        row.style.display = transactionID.includes(searchValue) ? "" : "none";
    });
}
